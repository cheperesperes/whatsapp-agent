-- Conversation-outcome schema migrations
-- ---------------------------------------------------------------------------
-- These migrations add the columns the marketing playbook depends on. They are
-- idempotent (safe to re-run). Run them in order; each is a separate logical
-- change, so they can be split across deploys.
--
-- After running, follow up with the queries in segmentation-queries.sql and
-- the dashboard queries in references/kpi-definitions.md.
-- ---------------------------------------------------------------------------


-- ===========================================================================
-- 1. customers — marketing-relevant flags and last-campaign tracking
-- ===========================================================================
alter table customers
  add column if not exists marketing_opt_in boolean not null default false,
  add column if not exists marketing_opt_in_at timestamptz,
  add column if not exists marketing_opt_in_source text,
  add column if not exists last_campaign_id uuid,
  add column if not exists last_campaign_sent_at timestamptz,
  add column if not exists do_not_message_until timestamptz,
  add column if not exists first_touch_channel text,    -- 'whatsapp' | 'web' | 'instagram' | …
  add column if not exists language text default 'es';

create index if not exists idx_customers_marketing_eligible
  on customers (marketing_opt_in, opted_out)
  where marketing_opt_in = true and opted_out = false;

create index if not exists idx_customers_last_campaign
  on customers (last_campaign_id);


-- ===========================================================================
-- 2. conversations — intent score, token + segment cost tracking
-- ===========================================================================
alter table conversations
  add column if not exists intent_score smallint,         -- 1..5, computed by Sol
  add column if not exists intent_classified_at timestamptz,
  add column if not exists tokens_used integer not null default 0,
  add column if not exists twilio_segments integer not null default 0,
  add column if not exists outcome text,                  -- 'converted' | 'opted_out' | 'abandoned' | 'escalated' | …
  add column if not exists outcome_at timestamptz;

create index if not exists idx_conversations_intent
  on conversations (intent_score, created_at desc);

create index if not exists idx_conversations_outcome
  on conversations (outcome);


-- ===========================================================================
-- 3. campaigns — outbound campaign metadata
-- ===========================================================================
create table if not exists campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  template_sid text not null,                  -- Twilio Content SID of approved template
  template_category text not null,             -- 'utility' | 'marketing' | 'authentication'
  segment_query text,                          -- the SQL used to build the audience, for audit
  recipients_count integer,
  cost_usd numeric(10,4),
  sent_at timestamptz,
  sent_by text,                                -- 'eduardo' | 'luz' | system user id
  hypothesis text,                             -- what we expected — for the weekly review
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists idx_campaigns_sent_at
  on campaigns (sent_at desc);


-- ===========================================================================
-- 4. opt-in evidence — proof for Meta audits and disputes
-- ===========================================================================
create table if not exists opt_in_evidence (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references customers(id) on delete cascade,
  opt_in_type text not null,                   -- 'general' | 'marketing'
  opted_in_at timestamptz not null default now(),
  source text not null,                        -- 'checkout-page' | 'facebook-leadform' | 'whatsapp-double-opt-in' | …
  evidence_url text,                           -- URL or storage reference to screenshot / form
  ip_address text,
  user_agent text,
  raw_payload jsonb                            -- full form data for completeness
);

create index if not exists idx_opt_in_evidence_customer
  on opt_in_evidence (customer_id, opted_in_at desc);


-- ===========================================================================
-- 5. RLS — keep the audit-skill rules consistent
-- ===========================================================================
-- The hardening skill already turned on RLS for customer-facing tables. The
-- new tables added here need the same treatment. Run as the postgres / owner
-- role.

alter table campaigns enable row level security;
alter table opt_in_evidence enable row level security;

-- Service role: full access (used by Sol's webhook + scheduled jobs).
drop policy if exists "service_role_all" on campaigns;
create policy "service_role_all" on campaigns
  for all to service_role using (true) with check (true);

drop policy if exists "service_role_all" on opt_in_evidence;
create policy "service_role_all" on opt_in_evidence
  for all to service_role using (true) with check (true);

-- Authenticated (admin UI): read-only.
drop policy if exists "authenticated_read" on campaigns;
create policy "authenticated_read" on campaigns
  for select to authenticated using (true);

drop policy if exists "authenticated_read" on opt_in_evidence;
create policy "authenticated_read" on opt_in_evidence
  for select to authenticated using (true);

-- anon (public): no access. (The default with RLS on; explicit for clarity.)


-- ===========================================================================
-- 6. Helpful joined view for the weekly review
-- ===========================================================================
create or replace view campaign_performance as
select
  cmp.id,
  cmp.name,
  cmp.template_category,
  cmp.sent_at,
  cmp.recipients_count,
  cmp.cost_usd,
  count(distinct o.id) as attributed_orders,
  coalesce(sum(o.total_amount), 0) as attributed_revenue,
  round(coalesce(sum(o.total_amount), 0) / nullif(cmp.cost_usd, 0), 2) as roi_multiple,
  count(distinct cust.id) filter (where cust.opted_out = true
    and cust.opted_out_at between cmp.sent_at and cmp.sent_at + interval '7 days') as opt_outs_7d
from campaigns cmp
left join customers cust on cust.last_campaign_id = cmp.id
left join orders o
  on o.customer_id = cust.id
 and o.created_at between cmp.sent_at and cmp.sent_at + interval '7 days'
group by cmp.id;

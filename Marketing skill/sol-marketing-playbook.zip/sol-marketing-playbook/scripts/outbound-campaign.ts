// Outbound campaign send loop
// ---------------------------------------------------------------------------
// Pattern for sending a Twilio WhatsApp template message to a list of
// customers, with:
//   - opt-out and marketing-opt-in filtering
//   - throttling (1 msg/sec default)
//   - per-recipient failure handling (set do_not_message_until on certain
//     errors, continue the campaign)
//   - campaign attribution (write last_campaign_id before send)
//   - cost tracking (total recipients × per-segment cost)
//
// Design rules:
//   1. The audience SQL runs ONCE at the start. It's stored on the campaign
//      row for audit. Don't recompute mid-send — it leads to drift.
//   2. Every recipient row gets `last_campaign_id` set before the send so
//      inbound replies can be attributed even if the send fails halfway.
//   3. On a single Twilio error, do NOT abort the whole campaign. Log and
//      move on. Abort only on auth errors or repeated 5xx.
//   4. STOP/BAJA/CANCELAR opt-out is enforced at the audience query level.
//      The webhook (hardening skill) is what catches it on inbound; this
//      script is what respects it on outbound.
// ---------------------------------------------------------------------------

import twilio from "twilio";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
);

const tw = twilio(
  process.env.TWILIO_ACCOUNT_SID!,
  process.env.TWILIO_AUTH_TOKEN!,
);

const FROM_NUMBER = process.env.TWILIO_WHATSAPP_NUMBER!;     // e.g. "whatsapp:+15551234567"
const PER_SEND_DELAY_MS = 1000;                              // 1 msg/sec default
const ABORT_ON_CONSECUTIVE_5XX = 5;                          // safety brake

export interface CampaignInput {
  name: string;                                              // human-readable, e.g. "abandoned-cart-2026-04"
  templateSid: string;                                       // Twilio Content SID, approved
  templateCategory: "utility" | "marketing" | "authentication";
  segmentSql: string;                                        // for audit; runs as service_role
  templateVariables: (recipient: Recipient) => Record<string, string>;
  hypothesis: string;                                        // what we expect — for the weekly review
  sentBy: string;                                            // 'eduardo' | 'luz' | …
}

export interface Recipient {
  customer_id: string;
  phone: string;            // E.164, e.g. "+15551234567" — NO "whatsapp:" prefix
  first_name: string | null;
  language: string | null;
}

export interface CampaignResult {
  campaignId: string;
  recipientsAttempted: number;
  successes: number;
  failures: number;
  costEstimateUsd: number;
}

/**
 * Run an outbound campaign end-to-end.
 *
 * Caller pre-validates the segment SQL (opt-out, marketing_opt_in, etc.).
 * This function does NOT add safety filters on top — it trusts the segment.
 * Use the segments in scripts/segmentation-queries.sql, which already have
 * the right filters baked in.
 */
export async function runCampaign(input: CampaignInput): Promise<CampaignResult> {
  // 1. Run the audience query and snapshot it.
  const { data: recipients, error: segErr } = await supabase.rpc("run_segment_sql", {
    sql: input.segmentSql,
  });
  if (segErr) throw new Error(`Segment SQL failed: ${segErr.message}`);
  if (!recipients || recipients.length === 0) {
    throw new Error("Segment returned 0 recipients. Aborting before any send.");
  }

  // 2. Insert the campaign row up front so attribution works even on failure.
  const { data: campaignRow, error: cmpErr } = await supabase
    .from("campaigns")
    .insert({
      name: input.name,
      template_sid: input.templateSid,
      template_category: input.templateCategory,
      segment_query: input.segmentSql,
      recipients_count: recipients.length,
      sent_at: new Date().toISOString(),
      sent_by: input.sentBy,
      hypothesis: input.hypothesis,
    })
    .select()
    .single();
  if (cmpErr || !campaignRow) throw new Error(`Campaign insert failed: ${cmpErr?.message}`);

  const campaignId = campaignRow.id;

  // 3. Tag every recipient with last_campaign_id BEFORE sending. If the send
  // fails halfway, inbound replies still attribute correctly.
  await supabase
    .from("customers")
    .update({ last_campaign_id: campaignId, last_campaign_sent_at: new Date().toISOString() })
    .in("id", recipients.map((r: Recipient) => r.customer_id));

  // 4. Send loop with throttle + failure handling.
  let successes = 0;
  let failures = 0;
  let consecutive5xx = 0;

  for (const r of recipients as Recipient[]) {
    try {
      const variables = input.templateVariables(r);
      await tw.messages.create({
        from: FROM_NUMBER,
        to: `whatsapp:${r.phone}`,
        contentSid: input.templateSid,
        contentVariables: JSON.stringify(variables),
      });
      successes++;
      consecutive5xx = 0;
    } catch (err: unknown) {
      failures++;
      await handleSendFailure(r, err);
      const status = (err as { status?: number })?.status ?? 0;
      if (status >= 500) consecutive5xx++;
      else consecutive5xx = 0;
      if (consecutive5xx >= ABORT_ON_CONSECUTIVE_5XX) {
        console.error(
          `[campaign ${input.name}] aborting after ${consecutive5xx} consecutive 5xx`,
        );
        break;
      }
    }
    await sleep(PER_SEND_DELAY_MS);
  }

  // 5. Cost estimate (rough — replace with real Twilio billing pull).
  const PER_SEGMENT_COST_USD = 0.005;
  const estimatedCostUsd = successes * PER_SEGMENT_COST_USD;
  await supabase
    .from("campaigns")
    .update({ cost_usd: estimatedCostUsd })
    .eq("id", campaignId);

  return {
    campaignId,
    recipientsAttempted: recipients.length,
    successes,
    failures,
    costEstimateUsd: estimatedCostUsd,
  };
}

/**
 * Handle a single send failure. Twilio error codes worth special-casing:
 *   63016 — failed to send freeform message outside the 24h window
 *           (means the template wasn't actually a template — fix and retry next time)
 *   63024 — number not on WhatsApp (mark do_not_message_until = +30d)
 *   63038 — daily message limit per user reached (mark +7d)
 *   63015 — frequency cap from Meta (mark +7d)
 *   21610 — recipient unsubscribed (mark opted_out)
 */
async function handleSendFailure(r: Recipient, err: unknown): Promise<void> {
  const code = (err as { code?: number })?.code;
  console.warn(`[campaign] send to ${r.customer_id} failed:`, code, err);

  switch (code) {
    case 21610:
      await supabase
        .from("customers")
        .update({ opted_out: true, opted_out_at: new Date().toISOString() })
        .eq("id", r.customer_id);
      return;
    case 63024:
      await supabase
        .from("customers")
        .update({
          do_not_message_until: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(),
        })
        .eq("id", r.customer_id);
      return;
    case 63038:
    case 63015:
      await supabase
        .from("customers")
        .update({
          do_not_message_until: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
        })
        .eq("id", r.customer_id);
      return;
    default:
      // Log only; don't sideline this customer for transient errors.
      return;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ---- Example usage ----
//
// import { readFileSync } from "node:fs";
//
// const segmentSql = readFileSync("scripts/segments/abandoned-cart.sql", "utf-8");
//
// const result = await runCampaign({
//   name: "abandoned-cart-2026-04",
//   templateSid: "HXxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
//   templateCategory: "marketing",
//   segmentSql,
//   templateVariables: (r) => ({
//     "1": r.first_name ?? "",
//   }),
//   hypothesis: "High-intent cart abandoners convert >5% within 7d when given " +
//               "a low-friction nudge (no discount). Goal: 5% conversion, <1% opt-out.",
//   sentBy: "eduardo",
// });
//
// console.log(result);
// // { campaignId: '...', recipientsAttempted: 134, successes: 131, failures: 3, costEstimateUsd: 0.66 }

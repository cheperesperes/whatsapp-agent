-- Sol segmentation queries
-- ---------------------------------------------------------------------------
-- These are the SQL patterns Sol's backend uses to:
--   (a) compute the nightly "intent bucket" per customer (Tier 3 personalization)
--   (b) build campaign audiences for outbound sends
--
-- Adapt table/column names to match Oiikon's actual schema. The queries assume:
--   customers(id, phone, first_name, language, created_at, opted_out,
--             marketing_opt_in, last_campaign_id, last_campaign_sent_at,
--             do_not_message_until)
--   conversations(id, customer_id, created_at, intent_score)
--   messages(id, conversation_id, direction, created_at)
--   orders(id, customer_id, created_at, total_amount)
--   site_events(customer_id, event_type, occurred_at, product_id)
--
-- Schema migrations to add the columns above are in conversation-outcomes.sql.
-- ---------------------------------------------------------------------------


-- ===========================================================================
-- VIEW: nightly intent bucket per customer
-- ===========================================================================
-- Refresh nightly (e.g. via Supabase scheduled function or external cron).
-- Sol reads this view at conversation start to inject the bucket into the
-- system prompt.

create or replace view customer_intent_bucket as
with last_purchase as (
  select customer_id, max(created_at) as last_purchase_at, count(*) as total_orders
  from orders group by customer_id
),
recent_cart as (
  select customer_id, max(occurred_at) as last_cart_event_at
  from site_events
  where event_type = 'cart_added'
    and occurred_at >= now() - interval '48 hours'
  group by customer_id
),
recent_view as (
  select customer_id, max(occurred_at) as last_view_at
  from site_events
  where event_type = 'product_viewed'
    and occurred_at >= now() - interval '14 days'
  group by customer_id
),
recent_inbound as (
  select c.customer_id, max(m.created_at) as last_inbound_at
  from messages m
  join conversations c on c.id = m.conversation_id
  where m.direction = 'inbound'
    and m.created_at >= now() - interval '24 hours'
  group by c.customer_id
)
select
  cust.id as customer_id,
  case
    when cust.opted_out then 'opted_out'
    when rc.last_cart_event_at is not null
      or (rv.last_view_at is not null and ri.last_inbound_at is not null) then 'high_intent'
    when lp.total_orders >= 2 then 'repeat_buyer'
    when rv.last_view_at is not null then 'browsing'
    when lp.total_orders is null and cust.created_at >= now() - interval '7 days' then 'new'
    when lp.last_purchase_at < now() - interval '90 days'
      or (rv.last_view_at is null and lp.total_orders is null) then 'dormant'
    else 'browsing'
  end as bucket,
  rc.last_cart_event_at,
  rv.last_view_at,
  ri.last_inbound_at,
  lp.last_purchase_at,
  lp.total_orders
from customers cust
left join last_purchase lp on lp.customer_id = cust.id
left join recent_cart rc on rc.customer_id = cust.id
left join recent_view rv on rv.customer_id = cust.id
left join recent_inbound ri on ri.customer_id = cust.id;


-- ===========================================================================
-- SEGMENT: high-intent — abandoned cart in last 48h
-- ===========================================================================
-- Use case: a marketing-template campaign nudging cart completion.
-- Filters: opted-in for marketing, not opted out, not recently messaged.

select
  cust.id as customer_id,
  cust.phone,
  cust.first_name,
  cust.language
from customers cust
join customer_intent_bucket b on b.customer_id = cust.id
where b.bucket = 'high_intent'
  and cust.marketing_opt_in = true
  and cust.opted_out = false
  and (cust.do_not_message_until is null or cust.do_not_message_until < now())
  and (cust.last_campaign_sent_at is null
       or cust.last_campaign_sent_at < now() - interval '7 days');


-- ===========================================================================
-- SEGMENT: dormant — no purchase in 90+ days
-- ===========================================================================
-- Use case: reactivation campaign.

select
  cust.id as customer_id,
  cust.phone,
  cust.first_name,
  cust.language,
  lp.last_purchase_at
from customers cust
join customer_intent_bucket b on b.customer_id = cust.id
left join (
  select customer_id, max(created_at) as last_purchase_at from orders group by customer_id
) lp on lp.customer_id = cust.id
where b.bucket = 'dormant'
  and cust.marketing_opt_in = true
  and cust.opted_out = false
  and (cust.do_not_message_until is null or cust.do_not_message_until < now())
  and (cust.last_campaign_sent_at is null
       or cust.last_campaign_sent_at < now() - interval '30 days')
order by lp.last_purchase_at desc nulls last;


-- ===========================================================================
-- SEGMENT: repeat buyers — for upsell / cross-sell
-- ===========================================================================
-- Use case: announce a complementary product to the most engaged customers.

select
  cust.id as customer_id,
  cust.phone,
  cust.first_name,
  cust.language,
  lp.total_orders,
  lp.last_purchase_at
from customers cust
join customer_intent_bucket b on b.customer_id = cust.id
join (
  select customer_id, count(*) as total_orders, max(created_at) as last_purchase_at
  from orders group by customer_id
) lp on lp.customer_id = cust.id
where b.bucket = 'repeat_buyer'
  and lp.total_orders >= 2
  and cust.marketing_opt_in = true
  and cust.opted_out = false
  and (cust.do_not_message_until is null or cust.do_not_message_until < now())
order by lp.total_orders desc, lp.last_purchase_at desc;


-- ===========================================================================
-- SEGMENT: new customers in welcome window
-- ===========================================================================
-- Use case: utility welcome flow (first 7 days).
-- Note: utility template, so marketing_opt_in is NOT required — but opted_out
-- still is.

select
  cust.id as customer_id,
  cust.phone,
  cust.first_name,
  cust.language,
  cust.created_at
from customers cust
where cust.created_at >= now() - interval '7 days'
  and cust.opted_out = false
  and not exists (
    select 1 from messages m
    join conversations c on c.id = m.conversation_id
    where c.customer_id = cust.id
      and m.direction = 'outbound'
      and m.created_at >= cust.created_at
  );


-- ===========================================================================
-- AUDIT QUERY: how is each bucket distributed right now?
-- ===========================================================================
-- Sanity check before campaigns. If 80% of customers are in 'dormant', the
-- bucketing logic probably needs tightening.

select
  bucket,
  count(*) as customers,
  round(100.0 * count(*) / sum(count(*)) over (), 1) as pct
from customer_intent_bucket
group by 1
order by 2 desc;
